---
name: pray-reel-video
description: Makes 9:16 Awake America prayer videos for TikTok/Reels/Shorts from a prayer topic and an uploaded photo or video, with word-by-word text, voiceover and calm music.
---

# Prayer reel video

Turns "make a prayer video about ___" plus an uploaded photo or video into a
finished 1080×1920 MP4 in the Awake America "Pray the Scriptures" style:

- the uploaded photo or video, under a 48% dark overlay, with a slow push-in
- "PRAY THE SCRIPTURES" and the verse reference at the top, and the Awake America logo at the bottom
- the prayer in big uppercase Barlow Condensed Bold, one phrase per screen; each
  word fades in (100 ms, ease-in) as the voice speaks it
- a calm, gentle voiceover reading the prayer, and soft piano-and-strings
  music underneath, both made on the spot (no API keys, nothing to license)

The person using this is not technical. Keep replies short and friendly, and
never ask them to run commands, open files or install anything.

## Workflow

### 1. Get the topic and the background

- **Topic:** what the prayer is about (anxiety, healing, a child, a country, a
  hard week, a verse they love...). If they give a verse, use it.
- **Background:** the photo or video they uploaded. In claude.ai, uploads are in
  `/mnt/user-data/uploads/`; list that folder to find it. Portrait (vertical)
  works best. Landscape is fine too: it gets cropped to fill the frame, so
  mention this if the main subject is near an edge.
- If no photo or video was uploaded, ask for one in a single sentence. If they
  want to go ahead without one, run without `--background`; the video then gets
  a plain misty blue-grey background.

Don't ask anything else up front. Defaults cover the rest.

### 2. Write the prayer

Write it yourself from the topic. Follow these rules:

- **Ground it in one real Bible verse** that fits the topic. Use a verse you
  know well, and give its exact reference (book chapter:verse). Never invent a
  verse or misattribute one. If you quote the verse word for word, use a
  public-domain translation (KJV or WEB); otherwise paraphrase it in the prayer
  without quotation marks.
- **Shape (6–9 phrases, 15–30 seconds):**
  1. 1–2 phrases speaking to the viewer's struggle in plain words (the hook).
     Example: "Your faith may feel weak,"
  2. 3–5 phrases praying to God, drawing on the verse, asking and trusting.
  3. End with "Amen." as its own phrase, or "In Jesus' name, Amen."
- **Each phrase is one screen:** 3–8 words, about 45 characters at most. Phrases
  can end mid-sentence with a comma; the next phrase continues the sentence.
- Warm, hopeful, reverent, simple words. Address God as "Lord", "Father",
  "Jesus" or "God", and capitalise "You"/"Your" when they refer to God.
- Avoid promising specific outcomes (healing, money, results). Avoid politics
  and denominational disputes, and keep it suitable for all ages.

### 3. Show it, then make the video right away

Show the prayer as a short list with the reference above it. Then say you're
making the video. Don't wait for approval, because changes are easy afterwards.

Write the spec and run the script. The first run in a conversation takes about
2–3 minutes, because it installs packages and the voice model; later runs take
about 1–2 minutes.

```bash
cat > /tmp/prayer.json <<'EOF'
{
  "reference": "PSALM 85:6",
  "phrases": [
    "Your faith may feel weak,",
    "but God is not finished with you.",
    "Lord, will You not revive us again,",
    "that Your people may rejoice in You?",
    "Breathe new life into my weary heart.",
    "Amen."
  ]
}
EOF
python3 <this skill's folder>/scripts/make_reel.py --spec /tmp/prayer.json \
  --background "/mnt/user-data/uploads/<their file>" --still
```

- `--still` also saves a PNG of the first screen. Look at it to check that the
  text is readable over their image before sending the video. If the image is
  very bright, set `"overlay": 0.6` in the spec and run again.
- The video is saved to `/mnt/user-data/outputs/prayer-reel-<reference>.mp4`.
  Share it with the user (use the file-sharing or present-files tool if one
  exists), with one line saying what it is. Then offer one easy next step, such as a
  different voice or a new prayer.
- Run the script with a timeout of at least 10 minutes, or in the background.

### 4. Changes the user may ask for

| They say | Do |
|---|---|
| "Change a line / make it shorter" | Edit `phrases`, run again |
| "Male voice" | `"voice": "am_michael"` (warm), or `"bm_george"` (British) |
| "Different female voice" | `"af_bella"`, or `"bf_emma"` (British). Default is `"af_heart"` |
| "Slower / faster" | `"speed"`: default 0.76; 0.68 is slower, 0.85 is faster |
| "Different music" | `"seed"`: any other number gives a new melody in the same calm style |
| "Music louder/softer" | `"musicVolume"`: default 0.22 (0.1–0.35) |
| "Darker / lighter background" | `"overlay"`: default 0.48 (0.3–0.7) |
| "No movement on the photo" | `"zoom": 1` |
| "Different top text" | `"header": ["PRAY THE SCRIPTURES", "PSALM 23:1"]` (any 1–2 short lines) |
| "No voice" | add `--no-voice`; words then appear quickly one after another |

Later runs in the same conversation skip setup, so a change takes about 1–2 minutes.

## If something fails

The script prints `[pray-reel] ERROR: ...` with the reason. Tell the user in
plain words, with the fix:

- **`VOICE_MODEL_BLOCKED`**: the sandbox can't reach github.com to fetch the
  voice. Ask them to turn on network access for github.com in
  **Settings > Capabilities**, then start a new chat and try again. Meanwhile,
  offer a version without voice (`--no-voice`).
- **`BROWSER_BLOCKED`**: no video renderer could be found or downloaded. Ask
  them to allow **remotion.media** in **Settings > Capabilities**, then start
  a new chat.
- **Node.js/npm missing**: the video can't be made in this environment. Say so
  plainly.
- **"Background file not found"**: list `/mnt/user-data/uploads/` and use the
  right file name.

Work is kept in `~/pray-reel-work` (the project, models and the raw render).
You can delete it safely; the next run sets it up again.

## What's inside

- `scripts/make_reel.py`: the one command. It handles setup, voice, music,
  render and loudness (−14 LUFS, the level TikTok/Reels expect).
- `scripts/gen_voice.py`: Kokoro voiceover and per-word timing.
- `scripts/gen_music.py`: calm music bed made from scratch.
- `project/`: the Remotion video project. The design is Figma "Template 4" from
  the AA Design System: Barlow Condensed Bold 164 px, Inter SemiBold header,
  logo 80 px from the bottom.
