import { z } from 'zod';

/** Props for the PrayScripture reel (Figma "Template 4"). Edited in pray.json. */
export const praySchema = z.object({
  /** Small lines at the top, e.g. ["PRAY THE SCRIPTURES", "PSALM 85:6"]. */
  header: z.array(z.string()),
  /** One phrase per screen. Spoken by the voiceover and revealed word by word. */
  phrases: z.array(z.string()).min(1),
  /** Background photo or video in public/ (portrait works best). Videos loop, muted. */
  background: z.string(),
  /** Logo in public/, shown at the bottom. */
  logo: z.string().optional(),
  /** Dark overlay on the background, 0-1. Figma uses 0.48. */
  overlay: z.number().min(0).max(1),
  /** Slow push-in over the whole reel. 1 = no movement. */
  zoom: z.number().min(1).max(1.3),
  /** Voice settings, read by scripts/gen_voice.py. */
  voice: z.object({
    name: z.string(),
    speed: z.number(),
    leadInSeconds: z.number(),
    gapSeconds: z.number(),
    tailSeconds: z.number(),
  }),
  /** Music bed in public/, made by scripts/gen_music.py or any track you add. */
  music: z.string().optional(),
  musicVolume: z.number().min(0).max(1),
});

export type PrayProps = z.infer<typeof praySchema>;

export type WordTiming = { text: string; start: number; end: number };
export type PhraseTiming = { text: string; start: number; end: number; words: WordTiming[] };
export type VoiceTiming = { durationSeconds: number; phrases: PhraseTiming[] };

export const TIMING_FILE = 'audio/pray/timing.json';
export const VOICE_FILE = 'audio/pray/voice.wav';
