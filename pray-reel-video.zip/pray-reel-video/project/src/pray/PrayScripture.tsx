import React, { useEffect, useState } from 'react';
import {
  AbsoluteFill,
  Audio,
  continueRender,
  delayRender,
  getStaticFiles,
  Img,
  interpolate,
  Loop,
  OffthreadVideo,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import { BODY_FONT, prayFontsReady } from './fonts';
import { PhraseText } from './PhraseText';
import { VOICE_FILE, type PrayProps, type VoiceTiming } from './schema';

export type PrayInternalProps = PrayProps & { timing?: VoiceTiming; hasVoice?: boolean; videoFrames?: number };

const hasFile = (p?: string) => !!p && getStaticFiles().some((f) => f.name === p);
export const isVideo = (p: string) => /\.(mp4|mov|m4v|webm|mkv)$/i.test(p);

/** Figma "Template 4": photo or video + 48% overlay, header, word-by-word phrase, logo. */
export const PrayScripture: React.FC<PrayInternalProps> = (props) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const t = frame / fps;

  // Text layout measures the real font, so wait for it before the first frame.
  const [handle] = useState(() => delayRender('Loading pray fonts'));
  const [ready, setReady] = useState(false);
  useEffect(() => {
    prayFontsReady.then(() => {
      setReady(true);
      continueRender(handle);
    });
  }, [handle]);

  const phrases = props.timing?.phrases ?? [];
  // Each phrase stays on screen until the next one starts.
  const current = [...phrases].reverse().find((p) => t >= p.start);

  const zoom = interpolate(frame, [0, durationInFrames], [1, props.zoom]);
  const bg = hasFile(props.background) ? props.background : null;
  const logo = hasFile(props.logo) ? props.logo : null;

  return (
    <AbsoluteFill style={{ backgroundColor: '#1b2128' }}>
      {bg && isVideo(bg) ? (
        // Uploaded clips loop silently for the whole reel, cropped to fill 9:16.
        <Loop durationInFrames={Math.max(1, props.videoFrames ?? durationInFrames)}>
          <OffthreadVideo
            src={staticFile(bg)}
            muted
            style={{ width: '100%', height: '100%', objectFit: 'cover', transform: `scale(${zoom})` }}
          />
        </Loop>
      ) : bg ? (
        <Img
          src={staticFile(bg)}
          style={{ width: '100%', height: '100%', objectFit: 'cover', transform: `scale(${zoom})` }}
        />
      ) : (
        // Placeholder in the Figma photo's misty blue-grey when no background is set.
        <AbsoluteFill style={{ background: 'linear-gradient(#8f9a9a 0%, #5d6a72 35%, #2a3640 60%, #1a222a 100%)' }} />
      )}
      <AbsoluteFill style={{ backgroundColor: `rgba(22,22,22,${props.overlay})` }} />

      {props.header.length ? (
        <div
          style={{
            position: 'absolute',
            top: 80,
            left: '50%',
            transform: 'translateX(-50%)',
            fontFamily: BODY_FONT,
            fontWeight: 600,
            fontSize: 32,
            lineHeight: '44px',
            color: '#eff3fd',
            textAlign: 'center',
            whiteSpace: 'nowrap',
          }}
        >
          {props.header.map((line, i) => (
            <div key={i}>{line}</div>
          ))}
        </div>
      ) : null}

      {ready && current ? <PhraseText key={current.start} phrase={current} /> : null}

      {logo ? (
        <Img
          src={staticFile(logo)}
          style={{
            position: 'absolute',
            bottom: 80,
            left: '50%',
            transform: 'translateX(-50%)',
            width: 165.455,
            height: 79.737,
          }}
        />
      ) : null}

      {props.hasVoice ? <Audio src={staticFile(VOICE_FILE)} /> : null}
      {hasFile(props.music) ? (
        <Audio
          src={staticFile(props.music!)}
          volume={(f) =>
            props.musicVolume *
            interpolate(f, [durationInFrames - fps * 2, durationInFrames], [1, 0], {
              extrapolateLeft: 'clamp',
              extrapolateRight: 'clamp',
            })
          }
        />
      ) : null}
    </AbsoluteFill>
  );
};
