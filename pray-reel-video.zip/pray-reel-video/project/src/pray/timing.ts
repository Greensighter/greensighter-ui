import type { PhraseTiming, PrayProps, VoiceTiming } from './schema';

/**
 * Figma text animation for Template 4 (node 6168:7279):
 * Each = word, order = left to right, direction = in, opacity 0 -> 100%,
 * ease-in bezier(0.42, 0, 1, 1). The 500 ms preset is spread over the phrase:
 * every word fades for 100 ms, 100 ms after the previous one.
 */
export const WORD_FADE_SECONDS = 0.1;
export const WORD_STAGGER_SECONDS = 0.1;
export const EASE_IN = [0.42, 0, 1, 1] as const;

/**
 * Without a voiceover, phrases still get a calm pace: words appear on the Figma
 * stagger and each phrase stays up long enough to read (about 3 words/second).
 */
export function timingWithoutVoice(props: PrayProps): VoiceTiming {
  const { leadInSeconds, gapSeconds, tailSeconds } = props.voice;
  let t = leadInSeconds;
  const phrases: PhraseTiming[] = props.phrases.map((text) => {
    const words = text.split(/\s+/).filter(Boolean);
    const hold = Math.max(1.6, words.length / 3);
    const p: PhraseTiming = {
      text,
      start: t,
      end: t + hold,
      words: words.map((w, i) => ({
        text: w,
        start: t + i * WORD_STAGGER_SECONDS,
        end: t + (i + 1) * WORD_STAGGER_SECONDS,
      })),
    };
    t += hold + gapSeconds;
    return p;
  });
  return { durationSeconds: t - gapSeconds + tailSeconds, phrases };
}

/** The voice timing only applies if it was generated from the same phrases. */
export function timingMatches(timing: VoiceTiming, props: PrayProps): boolean {
  return (
    timing.phrases.length === props.phrases.length &&
    timing.phrases.every((p, i) => p.text.trim() === props.phrases[i].trim())
  );
}
