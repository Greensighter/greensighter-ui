import React, { useMemo } from 'react';
import { Easing, interpolate, useCurrentFrame, useVideoConfig } from 'remotion';
import { measureText } from '@remotion/layout-utils';
import { DISPLAY_FONT } from './fonts';
import { EASE_IN, WORD_FADE_SECONDS } from './timing';
import type { PhraseTiming } from './schema';

// From Figma: Barlow Condensed Bold, 164 px, line-height 0.9, uppercase,
// centred in a 781 px wide box. The 3-line example is centred on y = 960.
const MAX_SIZE = 164;
const MIN_SIZE = 96;
const BOX_WIDTH = 781;
const MAX_LINES = 4;
const LINE_HEIGHT = 0.9;

type Line = { words: { text: string; index: number }[] };

function wrap(words: string[], size: number): Line[] | null {
  const space = measureText({ text: ' ', fontFamily: DISPLAY_FONT, fontSize: size, fontWeight: '700' }).width;
  const lines: Line[] = [];
  let cur: Line = { words: [] };
  let width = 0;
  for (let i = 0; i < words.length; i++) {
    const w = measureText({ text: words[i], fontFamily: DISPLAY_FONT, fontSize: size, fontWeight: '700' }).width;
    if (w > BOX_WIDTH) return null; // a single word is too wide at this size
    const next = cur.words.length ? width + space + w : w;
    if (next > BOX_WIDTH && cur.words.length) {
      lines.push(cur);
      cur = { words: [] };
      width = w;
    } else {
      width = next;
    }
    cur.words.push({ text: words[i], index: i });
  }
  if (cur.words.length) lines.push(cur);
  return lines;
}

/** Largest size (up to the Figma 164 px) at which the phrase fits in 4 lines. */
function fit(words: string[]): { size: number; lines: Line[] } {
  for (let size = MAX_SIZE; size >= MIN_SIZE; size -= 4) {
    const lines = wrap(words, size);
    if (lines && lines.length <= MAX_LINES) return { size, lines };
  }
  return { size: MIN_SIZE, lines: wrap(words, MIN_SIZE) ?? [{ words: words.map((text, index) => ({ text, index })) }] };
}

const easeIn = Easing.bezier(...EASE_IN);

export const PhraseText: React.FC<{ phrase: PhraseTiming }> = ({ phrase }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;

  const words = useMemo(() => phrase.words.map((w) => w.text.toUpperCase()), [phrase]);
  const { size, lines } = useMemo(() => fit(words), [words]);

  return (
    <div
      style={{
        position: 'absolute',
        left: '50%',
        top: 960,
        width: BOX_WIDTH,
        transform: 'translate(-50%, -50%)',
        fontFamily: DISPLAY_FONT,
        fontWeight: 700,
        fontSize: size,
        lineHeight: LINE_HEIGHT,
        color: '#ffffff',
        textAlign: 'center',
      }}
    >
      {lines.map((line, li) => (
        <div key={li} style={{ whiteSpace: 'nowrap' }}>
          {line.words.map(({ text, index }, wi) => {
            const start = phrase.words[index].start;
            const opacity = interpolate(t, [start, start + WORD_FADE_SECONDS], [0, 1], {
              extrapolateLeft: 'clamp',
              extrapolateRight: 'clamp',
              easing: easeIn,
            });
            return (
              <React.Fragment key={index}>
                {wi > 0 ? ' ' : null}
                <span style={{ opacity }}>{text}</span>
              </React.Fragment>
            );
          })}
        </div>
      ))}
    </div>
  );
};
