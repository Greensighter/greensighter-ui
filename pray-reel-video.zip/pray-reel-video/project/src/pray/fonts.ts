import { loadFont } from '@remotion/fonts';
import { staticFile } from 'remotion';

// The two families used in Figma "Template 4", bundled in public/fonts (OFL).
export const DISPLAY_FONT = 'Barlow Condensed';
export const BODY_FONT = 'Inter';

export const prayFontsReady = Promise.all([
  loadFont({ family: DISPLAY_FONT, url: staticFile('fonts/BarlowCondensed-Bold.woff2'), weight: '700' }),
  loadFont({ family: BODY_FONT, url: staticFile('fonts/Inter-SemiBold.woff2'), weight: '600' }),
]);
